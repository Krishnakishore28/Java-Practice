package com.example.car.entity;

public class ModelTrans {
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ModelTrans [name=" + name + "]";
	}
	
}
