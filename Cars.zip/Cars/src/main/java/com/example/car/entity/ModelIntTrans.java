package com.example.car.entity;

public class ModelIntTrans {
	private int id;

	@Override
	public String toString() {
		return "ModelIntTrans [id=" + id + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
